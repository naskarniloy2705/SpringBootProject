package com.example.BookManagementSystem.exception;

public class PublisherNotFoundException extends RuntimeException {

	public PublisherNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PublisherNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public PublisherNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PublisherNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PublisherNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
